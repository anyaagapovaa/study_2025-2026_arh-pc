---
## Front matter
title: "Отчёт по лабораторной работе №5"
subtitle: "Архитектура компьютера"
author: "Агапова Анна Антоновна"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Рис."
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы
Приобретение практических навыков работы в Midnight Commander. Освоение инструкций языка ассемблера mov и int.

# Выполнение лабораторной работы
1.Открываю Midnight Commander с помощью команды mc. (рис. [-@fig-001])

![Открытие Midnight Commander](image/sf1.png){#fig-001 width=60%}

2.Пользуясь клавишами клавиатуры перехожу в каталог ~/work/arch-pc созданный при выполнении лабораторной работы №4. (рис. [-@fig-002])

![Переход в каталог](image/sf2.png){#fig-002 width=60%}

3.С помощью функциональной клавиши F7 создаю папку lab05 (рис. [-@fig-003]) и перехожу в созданный каталог. (рис. [-@fig-004])

![Создание папки](image/sf3.png){#fig-003 width=60%}

![Переход в каталог](image/sf4.png){#fig-004 width=60%}

4.Пользуясь строкой ввода и командой touch создаю файл lab5-1.asm. (рис. [-@fig-005])

![Создание файла](image/sf5.png){#fig-005 width=60%}

5.Проверю, что файл lab5-1.asm создался. (рис. [-@fig-006])

![Проверка создания файла](image/sf6.png){#fig-006 width=60%}

6.С помощью функциональной клавиши F4 открываю файл lab5-1.asm для редактирования во встроенном редакторе. Ввожу текст программы из листинга 5.1, сохраняю изменения и закрываю файл.(рис. [-@fig-007])

![Ввод текста программы](image/sf7.png){#fig-007 width=60%}

7.С помощью функциональной клавиши F3 открываю файл lab5-1.asm для просмотра. Убеждаюсь, что файл содержит текст программы.(рис. [-@fig-008])

![Проверка наличия текста программы](image/sf8.png){#fig-008 width=60%}

8.Оттранслирую текст программы lab5-1.asm в объектный файл. Выполняю компоновку объектного файла и запускаю получившийся исполняемый файл. (рис. [-@fig-009])

![Транслирование текста, поверка работы](image/sf9.png){#fig-009 width=60%}

9.Скачиваю файл in_out.asm со страницы курса в ТУИС. В одной из панелей mc открываю каталог с файлом lab5-1.asm. В другой панели каталог со скаченным файлом in_out.asm. Скопирую файл in_out.asm в каталог с файлом lab5-1.asm с помощью функциональной клавиши F5. (рис. [-@fig-0010])

![Копирование файла](image/sf10.png){#fig-0010 width=60%}

10.Проверю, что файл in_out.asm скопировался в каталог с файлом lab5-1.asm. (рис. [-@fig-0011])

![Проверка копирования файла](image/sf11.png){#fig-0011 width=60%}

11.С помощью функциональной клавиши F6 создаю копию файла lab5-1.asm с именем lab5-2.asm. (рис. [-@fig-0012])

![Создание копии файла](image/sf12.png){#fig-0012 width=60%}

12.Исправляю текст программы в файле lab5-2.asm с использование подпрограмм из внешнего файла in_out.asm, используя подпрограммы sprintLF, sread и quit в соответствии с листингом 5.2.  (рис. [-@fig-0013])

![Исправление текста программы](image/sf13.png){#fig-0013 width=60%}

13.Проверим работу исправленного текста программы. (рис. [-@fig-0014])

![Проверка работы](image/sf14.png){#fig-0014 width=60%}

14.Создаю копию файла lab5-1.asm. Внесу изменения в программу (без использования внешнего файла in_out.asm) и проверяю его работу.  (рис. [-@fig-0015])

![Проверка работы](image/sf15.png){#fig-0015 width=60%}

15.Создаю копию файла lab5-2.asm. Исправляю текст программы с использование подпрограмм из внешнего файла in_out.asm и проверяю его работу.  (рис. [-@fig-0016])

![Проверка работы](image/sf16.png){#fig-0016 width=60%}

# Выводы

В ходе лабораторной работы мною были приобретены практические навыки работы в Midnight Commander и освоение инструкций языка ассемблера mov и int.

# Список литературы
1. GDB: The GNU Project Debugger. — URL: https://www.gnu.org/software/gdb/.
2. GNU Bash Manual. — 2016. — URL: https://www.gnu.org/software/bash/manual/.
3. Midnight Commander Development Center. — 2021. — URL: https://midnight-commander.
org/.
4. NASM Assembly Language Tutorials. — 2021. — URL: https://asmtutor.com/.
5. Newham C. Learning the bash Shell: Unix Shell Programming. — O’Reilly Media, 2005. —
354 с. — (In a Nutshell). — ISBN 0596009658. — URL: http://www.amazon.com/Learningbash-Shell-Programming-Nutshell/dp/0596009658.
6. Robbins A. Bash Pocket Reference. — O’Reilly Media, 2016. — 156 с. — ISBN 978-1491941591.
7. The NASM documentation. — 2021. — URL: https://www.nasm.us/docs.php.
8. Zarrelli G. Mastering Bash. — Packt Publishing, 2017. — 502 с. — ISBN 9781784396879.
9. Колдаев В. Д., Лупин С. А. Архитектура ЭВМ. — М. : Форум, 2018.
10. Куляс О. Л., Никитин К. А. Курс программирования на ASSEMBLER. — М. : Солон-Пресс,
2017.
11. Новожилов О. П. Архитектура ЭВМ и систем. — М. : Юрайт, 2016.
12. Расширенный ассемблер: NASM. — 2021. — URL: https://www.opennet.ru/docs/RUS/nasm/.
13. Робачевский А., Немнюгин С., Стесик О. Операционная система UNIX. — 2-е изд. — БХВПетербург, 2010. — 656 с. — ISBN 978-5-94157-538-1.
14. Столяров А. Программирование на языке ассемблера NASM для ОС Unix. — 2-е изд. —
М. : МАКС Пресс, 2011. — URL: http://www.stolyarov.info/books/asm_unix.
15. Таненбаум Э. Архитектура компьютера. — 6-е изд. — СПб. : Питер, 2013. — 874 с. —
(Классика Computer Science).
16. Таненбаум Э., Бос Х. Современные операционные системы. — 4-е изд. — СПб. : Питер,
2015. — 1120 с. — (Классика Computer Science).
